export function Google() {
    const element = document.createElement('img');
    element.setAttribute('src','img/icons/googleIcon.svg');

    return element;
}