export function TitleModalComponent() {
    const element = document.createElement('div');
    element.classList.add('title-modal');
    element.append("You lose!")

    return element
}