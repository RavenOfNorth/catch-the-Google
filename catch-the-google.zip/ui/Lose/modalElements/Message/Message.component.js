export function Message() {
    const element = document.createElement('div');
    element.classList.add('text-modal');
    element.append("You'll be lucky next time")

    return element
}