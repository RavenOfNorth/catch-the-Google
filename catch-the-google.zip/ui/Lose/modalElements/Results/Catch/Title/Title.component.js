export function TitleCatchComponent() {
    const element = document.createElement('span')
    element.classList.add('result-title');

    element.append('Catch:')

    return element;
}