export function LoseIconComponent() {
    const element = document.createElement('img');
    element.setAttribute('src', "img/icons/lossIcon.svg");

    return element
}