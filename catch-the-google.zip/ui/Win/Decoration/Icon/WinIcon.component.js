export function WinIconComponent() {
    const element = document.createElement('img');
    element.setAttribute('src', "img/icons/winnerIcon.svg");

    return element
}