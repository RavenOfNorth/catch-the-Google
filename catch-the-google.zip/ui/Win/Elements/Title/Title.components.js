export function TitleComponent() {
    const element = document.createElement('div');
    element.classList.add('title-modal');
    element.append("You win!")

    return element
}