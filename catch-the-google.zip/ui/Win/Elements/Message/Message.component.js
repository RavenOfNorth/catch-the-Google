export function Message() {
    const element = document.createElement('div');
    element.classList.add('text-modal');
    element.append("You're awesome!'")

    return element
}